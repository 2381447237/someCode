/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter6;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

/**
 * Created by lizanhong on 16/2/1.
 */
public class AttrView extends View {
    private static final String TAG = "AttrView";

    public AttrView(Context context) {
        super(context);
    }

    public AttrView(Context context, AttributeSet attrs) {
        this(context, attrs, R.attr.myStyle);
    }

    public AttrView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.AttrView,
                defStyleAttr, R.style.myDefaultStyle);
        String attr1 = a.getString(R.styleable.AttrView_attr1);
        String attr2 = a.getString(R.styleable.AttrView_attr2);
        String attr3 = a.getString(R.styleable.AttrView_attr3);
        String attr4 = a.getString(R.styleable.AttrView_attr4);

        Log.i(TAG, attr1 + "");
        Log.i(TAG, attr2 + "");
        Log.i(TAG, attr3 + "");
        Log.i(TAG, attr4 + "");
    }

}
