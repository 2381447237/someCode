/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter7;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by lizanhong on 16/2/4.
 */
public class CornerLayout3 extends ViewGroup{
    private static final String TAG = "CornerLayout2";
    public CornerLayout3(Context context) {
        super(context);
    }

    public CornerLayout3(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CornerLayout3(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    /**
     * 定位子组件
     */
    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int leftPadding = getPaddingLeft();
        int rightPadding = getPaddingRight();
        int topPadding = getPaddingTop();
        int bottomPadding = getPaddingBottom();

        for(int i = 0; i < getChildCount(); i ++){
            View child = getChildAt(i);
            PositionLayoutParams layoutParams = (PositionLayoutParams)
                    child.getLayoutParams();
            int leftMargin = layoutParams.leftMargin;
            int rightMargin = layoutParams.rightMargin;
            int topMargin = layoutParams.topMargin;
            int bottomMargin = layoutParams.bottomMargin;
            int position = layoutParams.position;
            Log.i(TAG, "leftMargin:" + leftMargin + " rightMargin:"
                    + rightMargin + " topMargin:" + topMargin
                    + " bottomMargin:" + bottomMargin);
            if(i == 0 && position == PositionLayoutParams.NONE
                    || position == PositionLayoutParams.LEFT_TOP){
                //定位到左上角
                child.layout(leftPadding + leftMargin,
                        topPadding + topMargin,
                        child.getMeasuredWidth() + leftPadding + leftMargin,
                        child.getMeasuredHeight() + topPadding + topMargin);
            }else if(i == 1 && position == PositionLayoutParams.NONE
                    || layoutParams.position == PositionLayoutParams.RIGHT_TOP){
                //定位到右上角
                child.layout(getMeasuredWidth() - child.getMeasuredWidth()
                                - rightPadding - rightMargin,
                        topPadding + rightMargin,
                        getMeasuredWidth() - rightPadding - rightMargin,
                        child.getMeasuredHeight() + topPadding + rightMargin);
            }else if(i == 2 && position == PositionLayoutParams.NONE
                    || layoutParams.position == PositionLayoutParams.LEFT_BOTTOM){
                //定位到左下角
                child.layout(leftPadding + leftMargin,
                        getMeasuredHeight() - child.getMeasuredHeight()
                                - bottomPadding - bottomMargin,
                        child.getMeasuredWidth() + leftPadding + leftMargin,
                        getMeasuredHeight() - bottomPadding - bottomMargin);
            }else if(i == 3 && position == PositionLayoutParams.NONE
                    || layoutParams.position == PositionLayoutParams.RIGHT_BOTTOM){
                //定位到右下角
                child.layout(getMeasuredWidth() - child.getMeasuredWidth()
                                - rightPadding - rightMargin,
                        getMeasuredHeight() - child.getMeasuredHeight()
                                - bottomPadding - bottomMargin,
                        getMeasuredWidth() - rightPadding - rightMargin,
                        getMeasuredHeight() - bottomPadding - bottomMargin);
            }
        }
    }

    /**
     * 测量尺寸
     * @param widthMeasureSpec
     * @param heightMeasureSpec
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        //先测量所有子组件的大小
        this.measureChildren(widthMeasureSpec, heightMeasureSpec);
        //再测量自己的大小
        int width = this.measureWidth(widthMeasureSpec);
        int height = this.measureHeight(heightMeasureSpec);
        //应用
        this.setMeasuredDimension(width, height);
    }

    /**
     * 测量容器的宽度
     * @param widthMeasureSpec
     * @return
     */
    private int measureWidth(int widthMeasureSpec){
        int mode = MeasureSpec.getMode(widthMeasureSpec);
        int size = MeasureSpec.getSize(widthMeasureSpec);
        int width = 0;
        if(mode == MeasureSpec.EXACTLY) {
            //match_parent或具体值
            width = size;
        }else if(mode == MeasureSpec.AT_MOST){
            //wrap_content
            int aWidth, bWidth, cWidth, dWidth;
            aWidth = bWidth = cWidth = dWidth = 0;
            int marginHa, marginHb, marginHc, marginHd;
            marginHa = marginHb = marginHc = marginHd = 0;

            for(int i = 0; i < this.getChildCount(); i ++){
                MarginLayoutParams layoutParams = (MarginLayoutParams)
                        getChildAt(i).getLayoutParams();
                if(i == 0) {
                    aWidth = getChildAt(i).getMeasuredWidth();
                    marginHa += layoutParams.leftMargin + layoutParams.rightMargin;
                }else if(i == 1) {
                    bWidth = getChildAt(i).getMeasuredWidth();
                    marginHb += layoutParams.leftMargin + layoutParams.rightMargin;
                }else if(i == 2) {
                    cWidth = getChildAt(i).getMeasuredWidth();
                    marginHc += layoutParams.leftMargin + layoutParams.rightMargin;
                }else if(i == 3) {
                    dWidth = getChildAt(i).getMeasuredWidth();
                    marginHd += layoutParams.leftMargin + layoutParams.rightMargin;
                }
            }
            width = Math.max(aWidth, cWidth) + Math.max(bWidth, dWidth)
                    + getPaddingLeft() + getPaddingRight()
                    + Math.max(marginHa, marginHc)
                    + Math.max(marginHb, marginHd);
        }
        return width;
    }

    /**
     * 测量容器的高度
     * @param heightMeasureSpec
     * @return
     */
    private int measureHeight(int heightMeasureSpec){
        int mode = MeasureSpec.getMode(heightMeasureSpec);
        int size = MeasureSpec.getSize(heightMeasureSpec);
        int height = 0;
        if(mode == MeasureSpec.EXACTLY) {
            //match_parent或具体值
            height = size;
        }else if(mode == MeasureSpec.AT_MOST){
            //wrap_content
            int aHeight, bHeight, cHeight, dHeight;
            aHeight = bHeight = cHeight = dHeight = 0;
            int marginVa, marginVb, marginVc, marginVd;
            marginVa = marginVb = marginVc = marginVd = 0;

            for(int i = 0; i < this.getChildCount(); i ++){
                MarginLayoutParams layoutParams = (MarginLayoutParams)
                        getChildAt(i).getLayoutParams();
                if(i == 0) {
                    aHeight = getChildAt(i).getMeasuredHeight();
                    marginVa += layoutParams.topMargin + layoutParams.bottomMargin;
                }else if(i == 1) {
                    bHeight = getChildAt(i).getMeasuredHeight();
                    marginVb += layoutParams.topMargin + layoutParams.bottomMargin;
                }else if(i == 2) {
                    cHeight = getChildAt(i).getMeasuredHeight();
                    marginVc += layoutParams.topMargin + layoutParams.bottomMargin;
                }else if(i == 3) {
                    dHeight = getChildAt(i).getMeasuredHeight();
                    marginVd += layoutParams.topMargin + layoutParams.bottomMargin;
                }
            }
            height = Math.max(aHeight, bHeight) + Math.max(cHeight, dHeight)
                + getPaddingTop() + getPaddingBottom()
                    + Math.max(marginVa, marginVb) + Math.max(marginVc, marginVd);
        }
        return height;
    }

    @Override
    public LayoutParams generateLayoutParams(AttributeSet attrs) {
        return new PositionLayoutParams(this.getContext(), attrs);
    }

    @Override
    protected LayoutParams generateLayoutParams(LayoutParams p) {
        return new PositionLayoutParams(p);
    }

    @Override
    protected LayoutParams generateDefaultLayoutParams() {
        return new PositionLayoutParams(LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT);
    }

    /**
     * 自定义LayoutParams
     */
    public static class PositionLayoutParams extends ViewGroup.MarginLayoutParams{
        public static final int LEFT_TOP = 0;
        public static final int RIGHT_TOP = 1;
        public static final int LEFT_BOTTOM = 2;
        public static final int RIGHT_BOTTOM = 3;
        public static final int NONE = -1;

        public int position;

        public PositionLayoutParams(Context c, AttributeSet attrs) {
            super(c, attrs);
            //读取layout_position属性
            TypedArray a = c.obtainStyledAttributes(attrs, R.styleable.CornerLayout3);
            position = a.getInt(R.styleable.CornerLayout3_layout_position, NONE);
            a.recycle();
        }

        public PositionLayoutParams(int width, int height) {
            super(width, height);
        }

        public PositionLayoutParams(MarginLayoutParams source) {
            super(source);
        }

        public PositionLayoutParams(LayoutParams source) {
            super(source);
        }
    }
}
