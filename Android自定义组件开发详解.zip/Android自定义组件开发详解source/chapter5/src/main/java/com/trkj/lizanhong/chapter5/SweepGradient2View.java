/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter5;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by lizanhong on 16/1/28.
 */
public class SweepGradient2View extends View {
    public SweepGradient2View(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        SweepGradient sg = new SweepGradient(300, 300,
                new int[]{Color.GREEN, Color.YELLOW, Color.RED, Color.GREEN}, null);
        paint.setShader(sg);
        canvas.drawOval(new RectF(0, 0, 600, 600), paint);
    }
}
