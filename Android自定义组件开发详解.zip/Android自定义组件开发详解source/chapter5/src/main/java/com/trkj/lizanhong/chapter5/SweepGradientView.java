/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter5;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by lizanhong on 16/1/28.
 */
public class SweepGradientView extends View {
    public SweepGradientView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        SweepGradient sg = new SweepGradient(300, 300, Color.GREEN, Color.YELLOW);
        paint.setShader(sg);
        canvas.drawRect(new Rect(0, 0, 600, 600), paint);
    }
}
