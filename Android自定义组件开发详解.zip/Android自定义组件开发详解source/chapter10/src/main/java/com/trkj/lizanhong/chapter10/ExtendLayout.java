/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter10;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * ListView列表项定义，ExtendLayout内必须有且只有一个LinearLayout的子组件
 * Created by lizanhong on 16/2/13.
 */
public class ExtendLayout extends ViewGroup {
    private static final String TAG = "ExtendLayout";
    public ExtendLayout(Context context) {
        this(context, null, 0);
    }

    public ExtendLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ExtendLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        TextView tvDelete = createDeleteButton();
        this.addView(tvDelete, 0);
    }

    /**
     * 返回删除按钮
     * @return
     */
    public View getDeleteButton(){
        return getChildAt(0);
    }

    @Override
    public void addView(View child, int width, int height) {
        super.addView(child, width, height);
        if(getChildCount() > 2){
            throw new IndexOutOfBoundsException("Sub view is too many.");
        }
    }


    /**
     * 创建删除按钮
     * @return
     */
    private TextView createDeleteButton(){
        TextView tvDelete = new TextView(getContext());
        tvDelete.setText("删除");
        tvDelete.setGravity(Gravity.CENTER);
        tvDelete.setBackgroundColor(Color.RED);
        tvDelete.setTextColor(Color.WHITE);
        final float scale = getContext().getResources().getDisplayMetrics().density;
        int px = (int) (10 * scale + 0.5f);
        tvDelete.setPadding(px * 2, px, px * 2, px);
        LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        tvDelete.setLayoutParams(lp);
        tvDelete.setClickable(true);
        return tvDelete;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        measureChildren(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(
                measureWidth(widthMeasureSpec),
                measureHeight(heightMeasureSpec)
        );
    }

    /**
     * 测量宽度，额外添加删除按钮的宽度
     * @param widthMeasureSpec
     * @return
     */
    private int measureWidth(int widthMeasureSpec){
        int mode = MeasureSpec.getMode(widthMeasureSpec);
        int size = MeasureSpec.getSize(widthMeasureSpec);
        int width = 0;
        int tvDeleteWidth = 0;
        if(mode == MeasureSpec.EXACTLY){
            width = size;
        }else if(mode == MeasureSpec.UNSPECIFIED
                || mode == MeasureSpec.AT_MOST){
            for(int i = 0; i < getChildCount(); i ++) {
                if(i == 1)
                    width = getChildAt(i).getMeasuredWidth();
            }
        }
        for(int i = 0; i < getChildCount(); i ++){
            if(i == 0)
                tvDeleteWidth = getChildAt(i).getMeasuredWidth();
        }
        return width + tvDeleteWidth;
    }

    /**
     * 测量高度
     * @param heightMeasureSpec
     * @return
     */
    private int measureHeight(int heightMeasureSpec){
        int mode = MeasureSpec.getMode(heightMeasureSpec);
        int size = MeasureSpec.getSize(heightMeasureSpec);
        int height = 0;
        if(mode == MeasureSpec.EXACTLY){
            height = size;
        }else if(mode == MeasureSpec.UNSPECIFIED
                || mode == MeasureSpec.AT_MOST){
            for(int i = 0; i < getChildCount(); i ++) {
                if (i == 1) {
                    height = getChildAt(i).getMeasuredHeight();
                }
            }
        }
        //调整删除按钮的高度
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, height);
        for(int i = 0; i < getChildCount(); i ++){
            if(i == 0)
                getChildAt(0).setLayoutParams(lp);
        }
        Log.i(TAG, "height:" + height);
        return height;
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        View tvDelete = getChildAt(0);
        int tvDeleteWidth = tvDelete.getMeasuredWidth();
        int tvDeleteHeight = tvDelete.getMeasuredHeight();
        tvDelete.layout(0, 0, tvDeleteWidth, tvDeleteHeight);
        getChildAt(1).layout(tvDeleteWidth, 0, getMeasuredWidth(), getMeasuredHeight());
        //隐藏删除按钮
        this.scrollTo(tvDeleteWidth, 0);
    }
}
