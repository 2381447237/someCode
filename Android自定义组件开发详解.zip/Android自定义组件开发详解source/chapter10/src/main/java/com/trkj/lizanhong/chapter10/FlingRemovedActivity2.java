/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter10;

import android.app.Activity;
import android.os.Bundle;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lizanhong on 16/2/11.
 */
public class FlingRemovedActivity2 extends Activity {
    private FlingRemovedListView2 lv;
    List<Map<String, String>> list = new ArrayList<Map<String, String>>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fling_removed2);
        lv = (FlingRemovedListView2) findViewById(R.id.lv);
        lv.setOnRemovedItemListener(new FlingRemovedListView2.OnRemovedItemListener() {
            @Override
            public void itemRemoved(int position, ListAdapter adapter) {
                list.remove(position);
                ((BaseAdapter)adapter).notifyDataSetChanged();
            }
        });
        init();
    }

    private void init(){
        for(int i = 0; i < 50; i ++){
            Map<String, String> map = new HashMap<String, String>();
            map.put("name", "李赞红" + i);
            map.put("company", "韬睿科技");
            list.add(map);
        }
        SimpleAdapter adapter = new SimpleAdapter(this, list,
                R.layout.item, new String[]{"name", "company"},
                new int[]{R.id.name, R.id.company});
        lv.setAdapter(adapter);
    }
}
