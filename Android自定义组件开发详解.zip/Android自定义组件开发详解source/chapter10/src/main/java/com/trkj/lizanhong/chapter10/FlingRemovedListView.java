/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter10;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ListView;

/**
 * 滑动删除列表项
 * Created by lizanhong on 16/2/11.
 */
public class FlingRemovedListView extends ListView {
    private static final String TAG = "FlingRemovedListView";
    private VelocityTracker velocityTracker;
    private float preX; //手指滑动过程中上一个点的x坐标
    private float firstX, firstY; //手指第一次按下的点的x坐标
    private View willFlingView;//要滑动的列表项View
    private int position = INVALID_POSITION;//要滑动的列表项View的索引位置
    private int touchSlop;//滑动最小距离
    private static final int SNAP_VELOCITY = 600;
    private boolean isSlide;

    public FlingRemovedListView(Context context) {
        this(context, null);
    }

    public FlingRemovedListView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FlingRemovedListView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        int action = ev.getAction();
        int x = (int) ev.getX();
        int y = (int) ev.getY();
        obtainVelocity(ev);
        switch (action){
            case MotionEvent.ACTION_DOWN:
                firstX = preX = x;
                firstY = y;
                position = this.pointToPosition(x, y);
                if(position != INVALID_POSITION){
                    int visibleIndex = position - getFirstVisiblePosition();
                    willFlingView = getChildAt(visibleIndex);
                }
                break;
            case MotionEvent.ACTION_MOVE:
                float xVelocity = velocityTracker.getXVelocity();
                Log.i(TAG, "xVelocity：" + xVelocity);
                if(Math.abs(xVelocity) > SNAP_VELOCITY
                        || Math.abs(x - firstX) > touchSlop
                        && Math.abs(y - firstY) < touchSlop)
                    isSlide = true;
                break;
            case MotionEvent.ACTION_UP:
                releaseVelocity();
                break;
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if(isSlide && position != INVALID_POSITION) {
            float x = (int) ev.getX();
            switch (ev.getAction()) {
                case MotionEvent.ACTION_MOVE:
                    float dx = preX - x;
                    willFlingView.scrollBy((int) dx, 0);
                    preX = x;
                    break;
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_UP:
                    willFlingView = null;
                    position = INVALID_POSITION;
                    this.releaseVelocity();
                    isSlide = false;
                    break;
            }
            return true;
        }

        return super.onTouchEvent(ev);
    }

    private void obtainVelocity(MotionEvent event){
        if(velocityTracker == null){
            velocityTracker = VelocityTracker.obtain();
        }
        velocityTracker.addMovement(event);
    }

    private void releaseVelocity(){
        if(velocityTracker != null){
            velocityTracker.clear();
            velocityTracker.recycle();
            velocityTracker = null;
        }
    }
}
