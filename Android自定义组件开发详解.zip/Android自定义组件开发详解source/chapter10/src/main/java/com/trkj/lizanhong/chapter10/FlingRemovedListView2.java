/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter10;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Scroller;

/**
 * 滑动删除列表项的ListView
 * Created by lizanhong on 16/2/11.
 */
public class FlingRemovedListView2 extends ListView {
    private static final String TAG = "FlingRemovedListView";
    private static final int SNAP_VELOCITY = 600;
    private static final int SLIDE_MASK = 0x1;//是否可以滑动
    private static final int IS_ROLLBACK_MASK = SLIDE_MASK << 1;//是否回退，如果回退不能删除列表项
    private int flags;//标识位
    private Scroller scroller;
    private VelocityTracker velocityTracker;
    private float preX; //手指滑动过程中上一个点的x坐标和y坐标
    private float firstX, firstY; //手指第一次按下的点的x坐标
    private View willFlingView;//要滑动的列表项View
    private int position = INVALID_POSITION;//要滑动的列表项View的索引位置
    private int touchSlop;//最小滑动距离
    private OnRemovedItemListener onRemovedItemListener;

    public FlingRemovedListView2(Context context) {
        this(context, null);
    }

    public FlingRemovedListView2(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FlingRemovedListView2(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        scroller = new Scroller(context);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    public void setOnRemovedItemListener(OnRemovedItemListener onRemovedItemListener) {
        this.onRemovedItemListener = onRemovedItemListener;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        int action = ev.getAction();
        int x = (int) ev.getX();
        int y = (int) ev.getY();
        obtainVelocity(ev);
        switch (action){
            case MotionEvent.ACTION_DOWN:
                if(!scroller.isFinished())
                    return super.dispatchTouchEvent(ev);
                firstX = preX = x;
                firstY = y;
                position = this.pointToPosition(x, y);
                if(position != INVALID_POSITION){
                    int visibleIndex = position - getFirstVisiblePosition();
                    willFlingView = getChildAt(visibleIndex);
                }
                break;
            case MotionEvent.ACTION_MOVE:
                float xVelocity = velocityTracker.getXVelocity();
                if(x > firstX && (Math.abs(xVelocity) > SNAP_VELOCITY
                        || Math.abs(x - firstX) > touchSlop
                        && Math.abs(y - firstY) < touchSlop))
                    flags |= SLIDE_MASK;
                break;
            case MotionEvent.ACTION_UP:
                releaseVelocity();
                break;
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if((flags & SLIDE_MASK) == SLIDE_MASK
                && position != INVALID_POSITION
                && willFlingView != null) {
            float x = (int) ev.getX();
            switch (ev.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    break;
                case MotionEvent.ACTION_MOVE:
                    float dx = preX - x;
                    willFlingView.scrollBy((int) dx, 0);
                    preX = x;
                    break;
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_UP:
                    int scrollX = willFlingView.getScrollX();
                    int listViewWidth = getMeasuredWidth();
                    if(Math.abs(scrollX) >= listViewWidth / 2){
                        //继续滑动
                        int remain = scrollX + listViewWidth;
                        scroller.startScroll(scrollX, 0,
                                -remain, 0, Math.abs(remain));
                        //设置回滚标识为0
                        flags &= ~IS_ROLLBACK_MASK;
                    }else{
                        //回退
                        scroller.startScroll(scrollX, 0, -scrollX, 0, Math.abs(scrollX));
                        //设置回滚标识为1
                        flags |= IS_ROLLBACK_MASK;
                    }

                    postInvalidate();
                    flags &= ~SLIDE_MASK;
                    break;
            }
            return true;
        }
        return super.onTouchEvent(ev);
    }

    @Override
    public void computeScroll() {
        if(scroller.computeScrollOffset()){
            willFlingView.scrollTo(scroller.getCurrX(), 0);
            postInvalidate();
            if(scroller.isFinished()){
                if(onRemovedItemListener != null){
                    //没有回退，则删除列表项
                    if((flags & IS_ROLLBACK_MASK) != IS_ROLLBACK_MASK) {
                        onRemovedItemListener.itemRemoved(position, getAdapter());
                        willFlingView.scrollTo(0, 0);
                    }
                }
            }
        }
    }

    private void obtainVelocity(MotionEvent event){
        if(velocityTracker == null){
            velocityTracker = VelocityTracker.obtain();
        }
        velocityTracker.addMovement(event);
    }

    private void releaseVelocity(){
        if(velocityTracker != null){
            velocityTracker.clear();
            velocityTracker.recycle();
            velocityTracker = null;
        }
    }

    /**
     * 删除列表项的回调接口
     */
    public interface OnRemovedItemListener {
        /**
         * 删除列表项
         * @param position 删除的列表项索引
         * @param adapter 适配器
         */
        void itemRemoved(int position, ListAdapter adapter);
    }
}
