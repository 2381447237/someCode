/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter10;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * To work on unit tests, switch the Test Artifact in the Build Variants view.
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }
}