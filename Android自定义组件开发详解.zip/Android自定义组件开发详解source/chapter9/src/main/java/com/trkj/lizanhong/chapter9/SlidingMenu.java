/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter9;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Point;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

/**
 * Created by lizanhong on 16/2/11.
 */
public class SlidingMenu extends HorizontalScrollView{
    private int leftPaddingWidth; //侧边栏的宽度
    private boolean isOpen = false;//侧边栏是否打开
    private boolean once = false;//默认只隐藏一次

    /**
     * 获取屏幕的宽度
     * @return
     */
    /**
     * 获取屏幕宽度
     * @return
     */
    private int getScreenWidth(){
        WindowManager wm = (WindowManager) getContext()
                .getSystemService(Context.WINDOW_SERVICE);
        Point point = new Point();
        wm.getDefaultDisplay().getSize(point);
        return  point.x;
    }

    /**
     * 指定侧边栏和主界面的宽
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        once = true;
        //水平滚动View只能有一个直接子组件
        LinearLayout subView = (LinearLayout) this.getChildAt(0);
        //指定侧边栏和主界面的宽
        //第0个子组件就是侧边栏，第1个组件就是主界面
        LinearLayout slidingMenu =
                (LinearLayout) subView.getChildAt(0);
        //第1个子组件是主界面
        ViewGroup content = (ViewGroup) subView.getChildAt(1);
        //设置侧边的宽度
        slidingMenu.getLayoutParams().width = leftPaddingWidth;
        //设置主界面的宽度
        content.getLayoutParams().width = this.getScreenWidth();
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    /**
     * 默认情况下在该方法中隐藏侧边栏
     */
    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        //下面的代码只调用一次
        if(once){
            //隐藏侧边栏
            this.scrollTo(leftPaddingWidth, 0);
        }
        once = false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        //当手指松开的时候，决定侧边栏是显示还是隐藏
        //如果侧边栏滚出屏幕的宽度大于侧边栏的一半，则隐藏侧边栏
        //如果侧边栏滚出屏幕的宽度小于等于侧边栏的一半，则显示侧边栏
        if(ev.getAction() == MotionEvent.ACTION_UP){
            int dx = this.getScrollX();
            int halfWidth = this.leftPaddingWidth / 2;
            Log.i("SlidingMenu", "dx:" + this.getScrollX() + " halfWidth:" + halfWidth);
            if(dx < halfWidth){
                //显示侧边栏
                this.smoothScrollTo(0, 0);
                Log.i("SlidingMenu", "显示");
                this.isOpen = true;
            }else{
                //隐藏侧边栏
                this.smoothScrollTo(leftPaddingWidth, 0);
                Log.i("SlidingMenu", "隐藏");
                this.isOpen = false;
            }
            return true;
        }

        return super.onTouchEvent(ev);
    }

    /**
     * 打开
     */
    public void open(){
        if(!isOpen){
            this.smoothScrollTo(0, 0);
            isOpen = true;
        }
    }

    /**
     * 隐藏
     */
    public void hide(){
        if(isOpen){
            this.smoothScrollTo(leftPaddingWidth, 0);
            isOpen = false;
        }
    }

    /**
     * 打开隐藏
     */
    public void toggle(){
        if(isOpen){
            hide();
        }else{
            open();
        }
    }


    public SlidingMenu(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public SlidingMenu(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs,
                R.styleable.SlidingMenu);
        leftPaddingWidth = a.getDimensionPixelSize(
                R.styleable.SlidingMenu_left_padding_width,
                (int) TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, 200,
                        context.getResources().getDisplayMetrics()));
        a.recycle();
    }

    public SlidingMenu(Context context) {
        super(context);
    }
}

