/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter9;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Scroller;

/**
 * 侧边栏（版本1）
 * Created by lizanhong on 16/2/10.
 */
public class SliderMenu2 extends ViewGroup {
    private static final String TAG = "SliderMenu";
    private static final int DO_MOVING = 0x001;//可以滑动
    private static final int NOT_MOVING = 0x002;//不可以滑动
    private int moving = NOT_MOVING; //是否可以滑动，默认不能滑动
    private static final int FLAG_SEPARATOR = 0x1;//标记变量，是否有分割线，占用最后一位
    private static final int FLAG_IS_OPEN = FLAG_SEPARATOR << 1;//标记变量，是否已打开，占用倒数第二位
    private int flags = FLAG_SEPARATOR >> 1;//存储标记变量，左移其实就是变成了0

    private int slidingWidth;//侧边栏宽度
    private float separator;//分割线宽度
    private int touchWidth;//感应宽度
    private int screenWidth;//屏幕宽度
    private Paint paint;
    private int preX, firstX;
    private Scroller scroller;

    public SliderMenu2(Context context) {
        this(context, null, 0);
    }

    public SliderMenu2(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /**
     * 初始化
     * @param context
     * @param attrs
     * @param defStyleAttr
     */
    public SliderMenu2(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.SliderMenu);
        slidingWidth = a.getDimensionPixelSize(
                R.styleable.SliderMenu_sliding_width,
                (int)TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, 150,
                        getResources().getDisplayMetrics()));
        separator = a.getDimensionPixelSize(
                R.styleable.SliderMenu_separator,
                (int)TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, 1
                        , getResources().getDisplayMetrics()));
        touchWidth = a.getDimensionPixelSize(
                R.styleable.SliderMenu_touch_width,
                (int) TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, 50,
                        getResources().getDisplayMetrics()));
        if(separator > 0)
            flags = flags | FLAG_SEPARATOR;
        a.recycle();
        screenWidth = getScreenWidth(context);
        setBackgroundColor(Color.alpha(255));
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.GRAY);
        paint.setStrokeWidth(separator);
        scroller = new Scroller(context);
    }

    /**
     * 子元素不能超过2个
     * @param child
     * @param index
     * @param params
     */
    @Override
    public void addView(View child, int index, LayoutParams params) {
        super.addView(child, index, params);
        if(getChildCount() > 2){
            throw new ArrayIndexOutOfBoundsException("Children count can't be more than 2.");
        }
    }

    /**
     * 获取屏幕宽度
     * @param context
     * @return
     */
    private int getScreenWidth(Context context){
        WindowManager wm = (WindowManager) getContext()
                .getSystemService(Context.WINDOW_SERVICE);
        Point point = new Point();
        wm.getDefaultDisplay().getSize(point);
        return  point.x;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        measureChildren(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(measureWidth(widthMeasureSpec),
                measureHeight(heightMeasureSpec));
    }

    /**
     * 总宽度 = 侧边栏宽度 + 主界面宽度 + 分割线宽度
     * @param widthMeasureSpec
     * @return
     */
    private int measureWidth(int widthMeasureSpec){
        int mode = MeasureSpec.getMode(widthMeasureSpec);
        int size = MeasureSpec.getSize(widthMeasureSpec);
        if(mode == MeasureSpec.AT_MOST){
            throw new IllegalStateException("layout_width can not be wrap_content.");
        }
        return (int) (screenWidth + slidingWidth + separator);
    }

    private int measureHeight(int heightMeasureSpec){
        int mode = MeasureSpec.getMode(heightMeasureSpec);
        int size = MeasureSpec.getSize(heightMeasureSpec);
        if(mode == MeasureSpec.AT_MOST){
            throw new IllegalStateException("layout_width can not be wrap_content");
        }
        int height = 0;
        if(mode == MeasureSpec.EXACTLY){
            height = size;
        }
        return height;
    }

    /**
     * 画分割线
     * @param canvas
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //画分割线
        if((flags & FLAG_SEPARATOR) == FLAG_SEPARATOR){
            int left = (int) (slidingWidth + separator / 2);
            canvas.drawLine(left, 0, left, getMeasuredHeight(), paint);
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        View slider = getChildAt(0);//侧边栏
        View mainUI = getChildAt(1);//主界面
        slider.layout(0, 0, slidingWidth, getMeasuredHeight());
        mainUI.layout((int) (slidingWidth + separator), 0, getMeasuredWidth(),
                getMeasuredHeight());
        this.scrollTo(slidingWidth, 0);//隐藏侧边栏
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getAction()){
            case MotionEvent.ACTION_DOWN:
                Log.i(TAG, "X：" + ev.getX());
                if((flags & FLAG_IS_OPEN) == FLAG_IS_OPEN){
                    moving = DO_MOVING;
                }else{
                    if(ev.getX() > touchWidth)
                        moving = NOT_MOVING;
                    else
                        moving = DO_MOVING;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                moving= NOT_MOVING;
                break;
        }
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(moving == NOT_MOVING)
            return false;
        int x = (int) event.getX();
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                preX = x;
                firstX = x;
                break;
            case MotionEvent.ACTION_MOVE:
                int dx = x - preX;
                this.scrollBy(-dx, 0);
                preX = x;
                break;
            case MotionEvent.ACTION_UP:
                dx = x - firstX;
                Log.i(TAG, "dx: " + dx);
                int remain = slidingWidth - Math.abs(dx);
                //dx右为正，左为负
                boolean isOpen = (flags & FLAG_IS_OPEN) == FLAG_IS_OPEN;
                if(dx > 0 && !isOpen) {
                    scroller.startScroll(getScrollX(), 0, -remain, 0);
                    flags = flags | FLAG_IS_OPEN;//置1
                }else if (dx < 0 && isOpen){
                    scroller.startScroll(getScrollX(), 0, remain, 0);
                    flags = flags & ~FLAG_IS_OPEN;//置0
                }else{
                    //校正（比如向右滑又向左滑）
                    scroller.startScroll(getScrollX(), 0, dx, 0);
                }
                invalidate();
                break;
        }

        return moving == DO_MOVING;
    }

    @Override
    public void computeScroll() {
        if(scroller.computeScrollOffset()){
            this.scrollTo(scroller.getCurrX(), 0);
            postInvalidate();
        }
    }

    /**
     * 打开侧边栏
     */
    public void open(){
        boolean isOpen = (flags & FLAG_IS_OPEN) == FLAG_IS_OPEN;
        if(!isOpen){
            scroller.startScroll(slidingWidth, 0, -slidingWidth, 0);
            invalidate();
            flags = flags | FLAG_IS_OPEN;
        }
    }

    /**
     * 关闭侧边栏
     */
    public void close(){
        boolean isOpen = (flags & FLAG_IS_OPEN) == FLAG_IS_OPEN;
        if(isOpen){
            scroller.startScroll(0, 0, slidingWidth, 0);
            invalidate();
            flags = flags & ~FLAG_IS_OPEN;
        }
    }

    /**
     * 打开/关闭侧边栏
     */
    public void toggle(){
        boolean isOpen = (flags & FLAG_IS_OPEN) == FLAG_IS_OPEN;
        if(isOpen)
            close();
        else
            open();
    }
}
