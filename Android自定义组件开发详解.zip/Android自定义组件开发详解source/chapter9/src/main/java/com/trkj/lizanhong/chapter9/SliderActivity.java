/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter9;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {
    private SliderMenu sm;
    //private  SlidingMenu sm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sliding_menu);
        sm = (SliderMenu) findViewById(R.id.sm);
        //setContentView(R.layout.sliding_menu2);
        //sm = (SlidingMenu) findViewById(R.id.slidingMenu);
        this.setTitle("侧边栏");
    }

    public void test(View view){
        Toast.makeText(this, "test", Toast.LENGTH_LONG).show();
    }

    public void toggle(View view){
        sm.toggle();
    }
}
