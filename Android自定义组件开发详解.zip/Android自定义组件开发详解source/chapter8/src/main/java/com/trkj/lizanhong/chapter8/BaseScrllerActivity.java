/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter8;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

/**
 * Created by lizanhong on 16/2/6.
 */
public class BaseScrllerActivity extends Activity{
    private BaseScrollerViewGroup scrollerViewGroup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_scroller);
        scrollerViewGroup = (BaseScrollerViewGroup) findViewById(R.id.scroll_layout);
    }

    /**
     * 滚动
     * @param view
     */
    public void start(View view){
        scrollerViewGroup.start();
    }

    /**
     * 取消
     * @param view
     */
    public void abort(View view){
        scrollerViewGroup.abort();
    }
}
