/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter8;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/**
 * Created by lizanhong on 16/2/5.
 */
public class ScrollToByActivity extends Activity {
    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scrolltoby);
        tv = (TextView) findViewById(R.id.tv);
    }

    public void scrollBy(View view){
        tv.scrollBy(-5, 0);
    }

    public void scrollTo(View view){
        int x = tv.getScrollX();
        int y = tv.getScrollY();
        tv.scrollTo(x - 5, y);
    }
}
