/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter8;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.Scroller;

/**
 * 触摸滑屏
 * Created by lizanhong on 16/2/6.
 */
public class MultiLauncher extends ViewGroup {
    private static final String TAG = "MultiLauncher";
    private static final int TOUCH_STATE_STOP = 0x001;//停止状态
    private static final int TOUCH_STATE_FLING = 0x002;//滑动状态
    private static final int SNAP_VELOCITY = 600 ; //最小的滑动速率

    private int curScreen; //当前屏
    private Scroller scroller;
    private int touchState = TOUCH_STATE_STOP;
    private int touchSlop = 0;//最小滑动距离，超过了，才认为开始滑动
    private float lastionMotionX = 0;//上次触摸屏的x位置
    private VelocityTracker velocityTracker;//速率跟踪器


    public MultiLauncher(Context context) {
        this(context, null);
    }

    public MultiLauncher(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public MultiLauncher(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        scroller = new Scroller(context);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    @Override
    public void computeScroll() {
        if(scroller.computeScrollOffset()){
            this.scrollTo(scroller.getCurrX(), scroller.getCurrY());
            postInvalidate();
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        int action = ev.getAction();
        final int x = (int) ev.getX();
        final int y = (int) ev.getY();
        if(action == MotionEvent.ACTION_MOVE &&
                touchState == TOUCH_STATE_STOP)
            return true;
        switch (action){
            case MotionEvent.ACTION_DOWN:
                lastionMotionX = x;
                touchState = scroller.isFinished() ? TOUCH_STATE_STOP
                        : TOUCH_STATE_FLING;
                break;
            case MotionEvent.ACTION_MOVE:
                //滑动距离过小不算滑动
                final int dx = (int) Math.abs(x - lastionMotionX);
                if(dx > touchSlop){
                    touchState = TOUCH_STATE_FLING;
                }
                break;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                touchState = TOUCH_STATE_STOP;
                break;
            default:
                break;
        }

        return touchState != TOUCH_STATE_STOP;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(velocityTracker == null){
            velocityTracker = VelocityTracker.obtain();
        }
        velocityTracker.addMovement(event);
        super.onTouchEvent(event);

        int action = event.getAction();
        final int x = (int) event.getX();
        switch (action){
            case MotionEvent.ACTION_DOWN:
                //手指按下时，如果正在滚动，则立刻停止
                if(scroller != null && !scroller.isFinished()){
                    scroller.abortAnimation();
                }
                lastionMotionX = x;
                break;
            case MotionEvent.ACTION_MOVE:
                int dx = (int) (lastionMotionX - x);
                scrollBy(dx, 0);
                lastionMotionX = x;
                break;
            case MotionEvent.ACTION_UP:
                final VelocityTracker velocityTracker = this.velocityTracker;
                velocityTracker.computeCurrentVelocity(1000);
                int velocityX = (int) velocityTracker.getXVelocity();

                if(velocityX > SNAP_VELOCITY && curScreen > 0){
                    moveToPrevious();
                }else if(velocityX < -SNAP_VELOCITY && curScreen < (getChildCount()-1)){
                    moveToNext();
                }else {
                    moveToDestination();
                }

                if(velocityTracker != null){
                    this.velocityTracker.clear();
                    this.velocityTracker.recycle();
                    this.velocityTracker = null;
                }
                touchState = TOUCH_STATE_STOP;
                break;
            case MotionEvent.ACTION_CANCEL:
                touchState = TOUCH_STATE_STOP;
                break;
        }
        return true;
    }

    /**
     * 滚动到下一屏
     */
    public void moveToNext(){
        moveToScreen(curScreen + 1);
    }

    /**
     * 滚动到上一屏
     */
    public void moveToPrevious(){
        moveToScreen(curScreen - 1);
    }

    /**
     * 移动到指定屏
     * @param whichScreen
     */
    public void moveToScreen(int whichScreen){
        Log.i(TAG, "moveToScreen");
        curScreen = whichScreen;
        Log.i(TAG, "curScreen:" + curScreen);
        if(curScreen > getChildCount() - 1)
            curScreen = getChildCount() - 1;

        if(curScreen < 0) curScreen = 0;

        int scrollX = getScrollX();
        //每一屏的宽度
        int splitWidth = getWidth() / getChildCount();
        //要移动的距离
        int dx = curScreen * splitWidth - scrollX;
        Log.i(TAG, " scrollX:" + scrollX + " dx:" + dx  + " splitWidth:" + splitWidth);
        //开始移动
        scroller.startScroll(scrollX, 0, dx, 0, Math.abs(dx));
        invalidate();
    }

    /**
     * 判断是回滚还是滑动到下一屏
     */
    public void moveToDestination(){
        Log.i(TAG, "moveToDestination");
        //每一屏的宽度
        int splitWidth = getWidth() / getChildCount();
        //判断是否回滚还是进入另一分屏
        int toScreen = (getScrollX() + splitWidth / 2 ) / splitWidth ;
        //移动到目标分屏
        moveToScreen(toScreen);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int n = this.getChildCount();
        int w = (r - l) / n;//分屏的宽度
        int h = b - t;//容器的高度

        for(int i = 0; i < n; i ++){
            View child = getChildAt(i);
            int left = i * w;
            int right = (i + 1) * w;
            int top = 0;
            int bottom = h;

            child.layout(left, top, right, bottom);
        }
    }

    /**
     * 测量容器本身的大小
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        measureChildren(widthMeasureSpec, heightMeasureSpec);

        int width = this.measureWidth(widthMeasureSpec);
        int height = this.measureHeight(heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    /**
     * 测量组件的宽度
     * @param widthMeasureSpec
     * @return
     */
    private int measureWidth(int widthMeasureSpec){
        int mode = MeasureSpec.getMode(widthMeasureSpec);
        int size = MeasureSpec.getSize(widthMeasureSpec);

        int width = 0;
        if(mode == MeasureSpec.AT_MOST){
            throw new IllegalArgumentException("Must not be MeasureSpec.AT_MOST.");
        }else{
            width = size;
        }

        //容器的宽度是屏幕的n倍，n是容器中子元素的个数
        return width * this.getChildCount();
    }

    /**
     * 测量组件的高度
     * @param heightMeasureSpec
     * @return
     */
    private int measureHeight(int heightMeasureSpec){
        int mode = MeasureSpec.getMode(heightMeasureSpec);
        int size = MeasureSpec.getSize(heightMeasureSpec);

        int height = 0;
        if(mode == MeasureSpec.AT_MOST){
            throw new IllegalArgumentException("Must not be MeasureSpec.AT_MOST.");
        }else{
            height = size;
        }
        return height;
    }
}
