/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter8;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by lizanhong on 16/2/5.
 */
public class ScrollToByLayoutActivity extends Activity {
    private LinearLayout linearlayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scrolltoby_layout);
        linearlayout = (LinearLayout) findViewById(R.id.linearlayout);
    }

    public void scrollBy(View view) {
        linearlayout.scrollBy(-5, 0);
    }

    public void scrollTo(View view) {
        int x = linearlayout.getScrollX();
        int y = linearlayout.getScrollY();
        linearlayout.scrollTo(x - 5, y);
    }
}
