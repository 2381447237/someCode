/*
 *  Copyright (c) 2016.
 *  韬睿科技 株洲新程IT教育 李赞红
 *  版权所有 严禁用于商业用途
 */

package com.trkj.lizanhong.chapter8;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}
